self.__precacheManifest = [
  {
    "revision": "8af2ca30d3a46e3f3955",
    "url": "/js/vendors~app.8af2ca30.js"
  },
  {
    "revision": "2278b66f08277a53d464",
    "url": "/js/app.2278b66f.js"
  },
  {
    "revision": "e59e781a12e9be8cc5edfd1d0d4bd344",
    "url": "/index.html"
  },
  {
    "revision": "8af2ca30d3a46e3f3955",
    "url": "/css/vendors~app.0.884fcde2.css"
  },
  {
    "revision": "2278b66f08277a53d464",
    "url": "/css/app.d51fd75b.css"
  }
];